package com.example.i_am_rich;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
